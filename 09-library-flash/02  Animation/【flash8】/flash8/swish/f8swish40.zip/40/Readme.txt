                         /'\
                     /\  \|/  /\
                     |\\_;=._//|
                      \."   "./
                      //^\ /^\\
               .'``",/ |�| |�| \,"``'.
              /   ,  `'\.---./'`  ,   \
             /`  /`\,."(     )".,/`\  `\
             /`     ( '.'-.-'.' )     `\
             /"`     "._  :  _."     `"\
              `/.'`"=.,_``=``_,.="`'.\`
             .-"-.      )   (      .-"-.
+-----------{'. '`}-----~   ~-----{'. '`}-----------+
|           `"---"`               `"---"`           |
�       Downloaded From GilesCotterill.co.uk        �
|                                                   |
+---------------------------------------------------+
| GilesCotterill.co.uk SWiSH - Logo of homepage     |
� Release Date: 29/10/2000    File Size: 16kb	    �
+---------------------------------------------------+
| Well this was made for my other site thearchives  |						
� its the title for the picture gallerys            �
+---------------------------------------------------+
+---------------------------------------------------+
� Disclaimer					    �
+---------------------------------------------------+
| You use this SWiSW @ your own risk. I am not to   |
� be held responsible for any problems that might   �
| occur while using this SWiSH.			    |
+---------------------------------------------------+
+---------------------------------------------------+
� Contact					    �
+---------------------------------------------------+
� Homepage: http://www.gilescotterill.co.uk         �
| E-mail: Gcotterill@cwcom.net                      |
+---------------------------------------------------+