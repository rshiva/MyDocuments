Heya!

Happy with your new downloaded Swish movie?
Im sure you are.
However i would like to point out that this swish movie contains personal material
and i dont want you to use that material for your own movie.
Dont worry, its only the picture of me that im talking about here.
I would really apreciate that.

Thanx
Cruise

Ps. Visit my board! http://www.bulletinhelp.com (i still need moderators) :)
