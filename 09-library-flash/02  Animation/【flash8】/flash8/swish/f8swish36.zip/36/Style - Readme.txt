It's all about style
Mike Pollock Copyright 2000
Created using SWiSH.

I created this flick as my second
attempt at animation with SWiSH.
The final result was quite pleasing
to me so here it is!  You may use
the source as a learning tool but
please - if you use it, give credit
where credit is due.  Thanks!

Pretty soon I will have my web
site up and running.  Check it out,
I am doing freelance web design
work (who isn't right?).  Anyway,
here's the URL....

http://www.Blueflies.net

"It's all about style"
